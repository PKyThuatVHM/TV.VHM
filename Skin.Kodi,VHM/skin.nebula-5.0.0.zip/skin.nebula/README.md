## Nebula skin for Kodi 16 KRYPTON
Simple and full-featured skin designed for Full HD TV screens.

![](http://i.imgur.com/UVLYuNY.jpg)

#### [Screenshots](https://github.com/Tgxcorporation/skin.nebula/wiki/Screenshots)

#### [Wiki](https://github.com/Tgxcorporation/skin.nebula/wiki)

#### [Changelog](https://github.com/Tgxcorporation/skin.nebula/blob/master/changelog.txt)

#### [Download from GitHub](https://github.com/Tgxcorporation/skin.nebula/wiki/Install-from-GitHub)

#### Thanks
All the Kodi/XBMC team and addon developers.

#### Donations
If you liked this skin and you want to help a little bit, you can donate here:

[![PayPal Donate](https://www.paypal.com/en_US/i/btn/x-click-but04.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=BQTJSRCZ8GWHY&lc=US&item_name=Skins%20by%20Tgx%20for%20Kodi%20Entertainment%20Center&item_number=Kodi&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted)
